﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double valorPeso;
        double valorAltura;
        double resultado;

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mskbPeso_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(mskbPeso.Text, out valorPeso)){
                lblAviso1.Text = "peso inválido";
                mskbPeso.Focus();
            }
            else
            {
                lblAviso1.Text = "";
            }
        }

        private void mskbAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(mskbAltura.Text, out valorAltura))
            {
                lblAviso2.Text = "altura inválida";
                mskbAltura.Focus();
            }
            else
            {
                lblAviso2.Text = "";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbPeso.Text = "";
            mskbAltura.Text = "";
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            resultado = valorPeso/Math.Pow(valorAltura,2);
            resultado = Math.Round(resultado);
            string resultadoTexto;
            if (resultado < 18.5)
            {
                resultadoTexto = "Magreza";
            }
            else if (resultado < 24.9)
            {
                resultadoTexto = "Normal";
            }
            else if (resultado < 29.9)
            {
                resultadoTexto = "Sobrepeso";

            }
            else if (resultado < 39.9)
            {
                resultadoTexto = "Obesidade";
            }
            else
            {
                resultadoTexto = "Obesidaed grave";
            }
            mskbImc.Text = (resultado + " " + resultadoTexto);
        }
    }
}

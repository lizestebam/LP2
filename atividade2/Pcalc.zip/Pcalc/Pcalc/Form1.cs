﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text= "";
            txtNum2.Text= "";
            txtResultado.Text = "";
            txtNum1.Focus();
            resultado = 0;
        }

        private void txtNum1_Validating(object sender, CancelEventArgs e)
        {
           
            if (!double.TryParse(txtNum1.Text, out numero1))
            {
                lblAlerta.Text = "Valor inválido";
                e.Cancel = true;
            }
            else 
            {
                lblAlerta.Text = "";            
            }
           

        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if(numero2 == 0) { lblAlerta.Text = "Divisão por zero"; }
            else { resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
                lblAlerta.Text = "";
            }
        }

        private void txtNum2_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out numero2))
            {
                lblAlerta.Text = "Valor inválido";
                e.Cancel = true;
            }
            else
            {
                lblAlerta.Text = "";
            }

        }

        private void btnPLus_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
            
        }

    }
}
